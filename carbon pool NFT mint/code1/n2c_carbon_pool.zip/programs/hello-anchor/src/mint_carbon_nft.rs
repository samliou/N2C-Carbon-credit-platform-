#[dependencies]
anchor-lang = "0.25.0"
anchor-spl = "0.25.0"
mpl-token-metadata = "1.2.0" # 假設版本號，實際使用時請檢查最新版本

use anchor_lang::prelude::*;
use anchor_spl::token::{self, MintTo, Token, TokenAccount};
use mpl_token_metadata::instruction::{create_metadata_accounts_v2, create_master_edition_v3};
use mpl_token_metadata::state::{Creator, DataV2};

declare_id!("CWhbNjj89FQuZ9NWrfc5zU96WWhV7pCRGybKwdq7qg3T"); // 使用自己的程式ID

#[program]
pub mod carbon_credit_nft {
    use super::*;

    pub fn mint_nft(
        ctx: Context<MintNft>,
        metadata: NftMetadata,
        uri: String,
        title: String,
        symbol: String,
    ) -> Result<()> {
        // 鑄造一個新的 NFT
        let cpi_accounts = MintTo {
            mint: ctx.accounts.mint.to_account_info(),
            to: ctx.accounts.token_account.to_account_info(),
            authority: ctx.accounts.mint_authority.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::mint_to(cpi_ctx, 1)?;

        // 創建元數據賬戶
        let creator = vec![Creator {
            address: ctx.accounts.mint_authority.key(),
            verified: false,
            share: 100,
        }];
        let data = DataV2 {
            name: title,
            symbol,
            uri,
            seller_fee_basis_points: 0,
            creators: Some(creator),
            collection: None,
            uses: None,
        };

        let accounts = vec![
            ctx.accounts.metadata.to_account_info(),
            ctx.accounts.mint.to_account_info(),
            ctx.accounts.mint_authority.to_account_info(),
            ctx.accounts.payer.to_account_info(),
            ctx.accounts.system_program.to_account_info(),
            ctx.accounts.rent.to_account_info(),
        ];

        let instruction = create_metadata_accounts_v2(
            ctx.accounts.token_metadata_program.key(),
            ctx.accounts.metadata.key(),
            ctx.accounts.mint.key(),
            ctx.accounts.mint_authority.key(),
            ctx.accounts.payer.key(),
            ctx.accounts.payer.key(),
            data.name.clone(),
            data.symbol.clone(),
            data.uri.clone(),
            data.creators.clone(),
            data.seller_fee_basis_points,
            true,
            false,
            None,
            None,
        );
        invoke(&instruction, &accounts)?;

        // 創建主版本
        let edition_accounts = vec![
            ctx.accounts.master_edition.to_account_info(),
            ctx.accounts.mint.to_account_info(),
            ctx.accounts.mint_authority.to_account_info(),
            ctx.accounts.payer.to_account_info(),
            ctx.accounts.metadata.to_account_info(),
            ctx.accounts.token_metadata_program.to_account_info(),
            ctx.accounts.token_program.to_account_info(),
            ctx.accounts.system_program.to_account_info(),
            ctx.accounts.rent.to_account_info(),
        ];

        let master_edition_instruction = create_master_edition_v3(
            ctx.accounts.token_metadata_program.key(),
            ctx.accounts.master_edition.key(),
            ctx.accounts.mint.key(),
            ctx.accounts.payer.key(),
            ctx.accounts.mint_authority.key(),
            ctx.accounts.metadata.key(),
            ctx.accounts.payer.key(),
            Some(0),
        );
        invoke(&master_edition_instruction, &edition_accounts)?;

        // 存儲元數據
        ctx.accounts.nft_account.metadata = metadata;
        ctx.accounts.nft_account.mint = ctx.accounts.mint.key();

        Ok(())
    }
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Default)]
pub struct NftMetadata {
    pub carbon_credit_serial: String,    // 碳權証明書序號
    pub carbon_credit_type: String,      // 碳權種類
    pub project_name: String,            // 碳權專案名
    pub tco2e_weight: u64,               // 碳權的tCO2e重量
    pub issuer: String,                  // 碳權發行來源
    pub certification_body: String,      // 認証單位
    pub issue_date: i64,                 // 碳權發行日期
}

#[derive(Accounts)]
pub struct MintNft<'info> {
    #[account(mut)]
    pub mint: Account<'info, token::Mint>,
    #[account(mut)]
    pub token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub mint_authority: Signer<'info>,
    #[account(mut)]
    pub payer: Signer<'info>,
    pub rent: Sysvar<'info, Rent>,
    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
    pub token_metadata_program: Program<'info, TokenMetadata>,
    /// CHECK: 這是未初始化的元數據賬戶
    #[account(mut)]
    pub metadata: UncheckedAccount<'info>,
    /// CHECK: 這是未初始化的主版本賬戶
    #[account(mut)]
    pub master_edition: UncheckedAccount<'info>,
    #[account(
        init,
        payer = payer,
        space = 8 + std::mem::size_of::<NftAccount>(),
        seeds = [b"nft", mint.key().as_ref()],
        bump
    )]
    pub nft_account: Account<'info, NftAccount>,
}

#[account]
pub struct NftAccount {
    pub metadata: NftMetadata,
    pub mint: Pubkey,
}

#[derive(Clone)]
pub struct TokenMetadata;

impl anchor_lang::Id for TokenMetadata {
    fn id() -> Pubkey {
        mpl_token_metadata::id()
    }
}