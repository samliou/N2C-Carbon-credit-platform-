#設置必要的依賴項和導入所需的庫：
use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token};
use mpl_token_metadata::instruction::{create_metadata_accounts_v2, create_master_edition_v3};
use solana_program::pubkey::Pubkey;

// 聲明程序 ID
declare_id!("BqncgezQmqi5hpvfmYojGEQQAH64t7TPmXGnRzN7ZGQz");

#定義 NFT 的元數據結構
#[program]
pub mod carbon_credit_nft {
    use super::*;

    pub fn mint_nft(
        ctx: Context<MintNft>,
        metadata: NftMetadata,
        uri: String,
        title: String,
        symbol: String,
    ) -> Result<()> {
        // 實現 NFT 鑄造邏輯
        let cpi_accounts = token::MintTo {
            mint: ctx.accounts.mint.to_account_info(),
            to: ctx.accounts.token_account.to_account_info(),
            authority: ctx.accounts.payer.to_account_info(),
        };

        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);

        token::mint_to(cpi_ctx, 1)?;

        // 創建元數據賬戶
        let account_info = vec![
            ctx.accounts.metadata.to_account_info(),
            ctx.accounts.mint.to_account_info(),
            ctx.accounts.mint_authority.to_account_info(),
            ctx.accounts.payer.to_account_info(),
            ctx.accounts.token_metadata_program.to_account_info(),
            ctx.accounts.token_program.to_account_info(),
            ctx.accounts.system_program.to_account_info(),
            ctx.accounts.rent.to_account_info(),
        ];

        let creator = vec![
            mpl_token_metadata::state::Creator {
                address: *ctx.accounts.mint_authority.key,
                verified: false,
                share: 100,
            },
        ];

        let instruction = create_metadata_accounts_v2(
            ctx.accounts.token_metadata_program.key(),
            ctx.accounts.metadata.key(),
            ctx.accounts.mint.key(),
            ctx.accounts.mint_authority.key(),
            ctx.accounts.payer.key(),
            ctx.accounts.payer.key(),
            title,
            symbol,
            uri,
            Some(creator),
            1,
            true,
            false,
            None,
            None,
        );

        invoke(&instruction, &account_info)?;

        // 創建主版本
        let master_edition_infos = vec![
            ctx.accounts.master_edition.to_account_info(),
            ctx.accounts.mint.to_account_info(),
            ctx.accounts.mint_authority.to_account_info(),
            ctx.accounts.payer.to_account_info(),
            ctx.accounts.metadata.to_account_info(),
            ctx.accounts.token_metadata_program.to_account_info(),
            ctx.accounts.token_program.to_account_info(),
            ctx.accounts.system_program.to_account_info(),
            ctx.accounts.rent.to_account_info(),
        ];

        let master_edition_instruction = create_master_edition_v3(
            ctx.accounts.token_metadata_program.key(),
            ctx.accounts.master_edition.key(),
            ctx.accounts.mint.key(),
            ctx.accounts.payer.key(),
            ctx.accounts.mint_authority.key(),
            ctx.accounts.metadata.key(),
            ctx.accounts.payer.key(),
            Some(0),
        );

        invoke(&master_edition_instruction, &master_edition_infos)?;

        // 將元數據存儲在程序中
        ctx.accounts.nft_account.metadata = metadata;
        ctx.accounts.nft_account.mint = ctx.accounts.mint.key();

        Ok(())
    }
}
-----------------
#定義賬戶結構
#[derive(Accounts)]
pub struct MintNft<'info> {
    #[account(mut)]
    pub mint: Account<'info, token::Mint>,
    #[account(mut)]
    pub token_account: Account<'info, token::TokenAccount>,
    #[account(mut)]
    pub mint_authority: Signer<'info>,
    #[account(mut)]
    pub payer: Signer<'info>,
    pub rent: Sysvar<'info, Rent>,
    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
    pub token_metadata_program: Program<'info, TokenMetadata>,
    /// CHECK: 這是未初始化的元數據賬戶
    #[account(mut)]
    pub metadata: UncheckedAccount<'info>,
    /// CHECK: 這是未初始化的主版本賬戶
    #[account(mut)]
    pub master_edition: UncheckedAccount<'info>,
    #[account(
        init,
        payer = payer,
        space = 8 + std::mem::size_of::<NftAccount>(),
        seeds = [b"nft", mint.key().as_ref()],
        bump
    )]
    pub nft_account: Account<'info, NftAccount>,
}

#[account]
pub struct NftAccount {
    pub metadata: NftMetadata,
    pub mint: Pubkey,
}

#[derive(Clone)]
pub struct TokenMetadata;

impl anchor_lang::Id for TokenMetadata {
    fn id() -> Pubkey {
        mpl_token_metadata::id()
    }
}